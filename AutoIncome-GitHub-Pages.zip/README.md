# AutoIncome — GitHub Pages

Esta carpeta contiene la versión estática de AutoIncome preparada para GitHub Pages.

## Publicación

1. Crea un repositorio público llamado `autoincome` en GitHub.
2. Sube `index.html` a la raíz del repositorio.
3. Ve a **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`.
6. Guarda los cambios.

La web quedará normalmente en:

`https://botardolora-dotcom.github.io/autoincome/`

## PayPal

Los botones de pago usan el enlace de PayPal proporcionado para AutoIncome.

No se incluyen contraseñas, Client Secret ni otras credenciales privadas.

## Nota

GitHub Pages sirve la parte estática de la web. El registro real de usuarios, base de datos y un área privada necesitarían posteriormente un backend o servicio externo.
